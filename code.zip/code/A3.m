clc; clear; close all;

% 1. 路径定义：
root_dir = 'D:\results';

% 获取根目录下所有的子文件夹
dir_info = dir(root_dir);
% 过滤掉 . 和 .. 以及非文件夹的项
dir_info = dir_info([dir_info.isdir] & ~ismember({dir_info.name}, {'.', '..'}));
num_folders = length(dir_info);

fprintf('共发现 %d 个任务文件夹，开始检查出图状态...\n', num_folders);
fprintf('--------------------------------------------------\n');

for i = 1:num_folders
    % 当前子文件夹名称及路径
    base_name = dir_info(i).name; 
    folder_path = fullfile(root_dir, base_name);
    
    % --- 【核心要求：检测是否存在，有了就不生成】 ---
    % 以最后一张图作为判断标准
    check_file = fullfile(folder_path, [base_name, '_4_Fig13_ParallaxProfile.png']);
    if exist(check_file, 'file')
        fprintf('[%d/%d] 跳过: %s (插图已存在)\n', i, num_folders, base_name);
        continue;
    end
    
    % 定义输入文件路径
    img_path = fullfile(folder_path, [base_name, '.bmp']);
    orig_xlsx_path = fullfile(folder_path, [base_name, '.xlsx']);
    core_xlsx_path = fullfile(folder_path, [base_name, '_core_area.xlsx']);
    
    % 检查必要数据是否齐全（特别是 Python 生成的 core_area）
    if ~exist(core_xlsx_path, 'file')
        fprintf('[%d/%d] 警告: %s (缺失 core_area 数据，请先运行 Python 脚本)\n', i, num_folders, base_name);
        continue;
    end

    fprintf('[%d/%d] 正在绘图: %s ...\n', i, num_folders, base_name);

    % --- 加载数据 ---
    raw_img = imread(img_path);
    orig_xlsx = readmatrix(orig_xlsx_path);
    core_xlsx = readmatrix(core_xlsx_path);
    
    % --- 预处理 ---
    mask = core_xlsx > 0; 
    mask = imfill(mask, 'holes');
    [H, W] = size(mask);
    [L, num_regions] = bwlabel(mask, 8);
    stats = regionprops(L, 'Centroid', 'Area');

    %% --- 图片 1：纯净二值检测图 ---
    f1 = figure('Visible', 'off');
    imshow(mask); set(gca, 'Position', [0 0 1 1]); 
    exportgraphics(f1, fullfile(folder_path, [base_name, '_1_Binary.png']));
    close(f1);

    %% --- 图片 2：黑底红边包白色实体图 (橙色序号) ---
    f2 = figure('Visible', 'off');
    imshow(double(mask)); hold on; 
    boundaries = bwboundaries(mask);
    for k = 1:length(boundaries)
        plot(boundaries{k}(:,2), boundaries{k}(:,1), 'r', 'LineWidth', 1.0); 
        if stats(k).Area > 50
            text(stats(k).Centroid(1), stats(k).Centroid(2), num2str(k), ...
                'Color', [1, 0.5, 0], 'FontSize', 4.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'center');
        end
    end
    set(gca, 'Position', [0 0 1 1]);
    exportgraphics(f2, fullfile(folder_path, [base_name, '_2_Segmentation.png']), 'Resolution', 300);
    close(f2);

    %% --- 图片 3：实景图高级标注 (蓝点骨架+极细绿线+微型绿字) ---
    f3 = figure('Visible', 'off');
    imshow(raw_img); hold on;
    skel = bwskel(mask); 
    dist_map = bwdist(~mask);
    for k = 1:num_regions
        if stats(k).Area < 100, continue; end
        sub_mask = (L == k);
        b_cell = bwboundaries(sub_mask);
        plot(b_cell{1}(:,2), b_cell{1}(:,1), 'r', 'LineWidth', 0.7);
        [sy, sx] = find(skel & sub_mask);
        plot(sx, sy, 'b.', 'MarkerSize', 1.2); 
        
        sorted_pts = sortrows([sy, sx], 1);
        sample_step = 35; 
        for j = 1:sample_step:size(sorted_pts,1)
            curr_y = sorted_pts(j,1); curr_x = sorted_pts(j,2);
            r_val = dist_map(curr_y, curr_x);
            line([curr_x-r_val, curr_x+r_val], [curr_y, curr_y], 'Color', 'g', 'LineWidth', 0.4);
            text(curr_x+r_val+5, curr_y, sprintf('%.1f', r_val*2), ...
                'Color', [0 1 0], 'FontSize', 4.5, 'FontWeight', 'bold');
        end
    end
    set(gca, 'Position', [0 0 1 1]);
    exportgraphics(f3, fullfile(folder_path, [base_name, '_3_Fig10_RealDetection.png']), 'Resolution', 300);
    close(f3);

    %% --- 图片 4：纵向视差剖面图 ---
    f4 = figure('Visible', 'off');
    set(f4, 'Color', 'w'); hold on;
    for k = 1:num_regions
        if stats(k).Area > 100
            [rows_idx, ~] = find(L == k);
            row_range = min(rows_idx):max(rows_idx);
            p_values = zeros(length(row_range), 1);
            for j = 1:length(row_range)
                pixels_in_row = orig_xlsx(row_range(j), L(row_range(j),:) == k);
                p_values(j) = mean(pixels_in_row);
            end
            plot(p_values, row_range, 'r-', 'LineWidth', 0.8);
            for j = 1:30:length(row_range)
                text(p_values(j)-1, row_range(j), sprintf('%d', round(p_values(j))), ...
                    'Color', [0 0.6 0], 'FontSize', 4.5, 'FontWeight', 'bold', 'HorizontalAlignment', 'right');
            end
        end
    end
    grid on; set(gca, 'YDir', 'reverse');
    ylabel('Vertical Position (Row Index)', 'FontSize', 10);
    xlabel('Parallax Value (p)', 'FontSize', 10);
    xlim([0 40]); ylim([0 H]);
    exportgraphics(f4, fullfile(folder_path, [base_name, '_4_Fig13_ParallaxProfile.png']), 'Resolution', 300);
    close(f4);

end

fprintf('--------------------------------------------------\n');
fprintf('批量绘图任务全部完成！\n');