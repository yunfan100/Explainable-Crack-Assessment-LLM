%%%%%%%%%%%%--- 批量处理+自动归档（V10 论文级整理版） ---%%%%%%%%%%%%
clc; clear; close all;

% 1. 路径定义
input_root = 'D:\demo';
output_root = 'D:\results';

% 确保输出根目录存在
if ~exist(output_root, 'dir'), mkdir(output_root); end

% 获取输入文件夹下所有的 .bmp 文件
img_files = dir(fullfile(input_root, '*.bmp'));
num_files = length(img_files);

if num_files == 0
    error('在指定路径下没有找到 .bmp 文件，请检查路径！');
end

fprintf('共发现 %d 张待处理图片，准备开始批量出图...\n', num_files);
fprintf('--------------------------------------------------\n');

for k = 1:num_files
    % --- (1) 获取当前文件名和路径 ---
    curr_filename = img_files(k).name;               % 如 "1 (5)_58.bmp"
    [~, base_name, ext] = fileparts(curr_filename);  % 如 "1 (5)_58"
    curr_full_path = fullfile(input_root, curr_filename);
    
    % --- (2) 创建该图片专属文件夹 ---
    sub_folder = fullfile(output_root, base_name);
    if ~exist(sub_folder, 'dir'), mkdir(sub_folder); end
    
    fprintf('[%d/%d] 正在处理: %s\n', k, num_files, curr_filename);
    
    % --- (3) 读取并预处理 ---
    raw_img = imread(curr_full_path);
    if size(raw_img, 3) == 3
        image_g = double(rgb2gray(raw_img));
    else
        image_g = double(raw_img);
    end
    
    %% --- (4) 核心算法---
    [vmax, umax] = size(image_g);
    v_map = [1:vmax]' * ones(1, umax);
    u_map = ones(vmax, 1) * [1:umax];
    v = reshape(v_map, [vmax*umax, 1]);
    u = reshape(u_map, [vmax*umax, 1]);
    d = reshape(image_g, [vmax*umax, 1]);
    
    % 剔除无效点
    u(d==0)=[]; v(d==0)=[]; d(d==0)=[];
    if isempty(d), continue; end % 如果是全黑图则跳过
    
    % 最小二乘平面拟合核心计算
    n = length(u);
    Su=sum(u); Sv=sum(v); Sd=sum(d);
    Su2=sum(u.^2); Sv2=sum(v.^2);
    Sdu=sum(u.*d); Sdv=sum(v.*d); Suv=sum(u.*v);
    
    beta0=(Sd^2*(Sv2+Su2)-2*Sd*(Sv*Sdv+Su*Sdu)+n*(Sdv^2+Sdu^2))/2;
    beta1=(Sd^2*(Sv2-Su2)+2*Sd*(Su*Sdu-Sv*Sdv)+n*(Sdv^2-Sdu^2))/2;
    beta2=-Sd^2*Suv+Sd*(Sv*Sdu+Su*Sdv)-n*Sdv*Sdu;
    gamma0=(n*Sv2+n*Su2-Sv^2-Su^2)/2;
    gamma1=(n*Sv2-n*Su2-Sv^2+Su^2)/2;
    gamma2=Sv*Su-n*Suv;
    A=(beta1*gamma0-beta0*gamma1); B=(beta0*gamma2-beta2*gamma0); C=(beta1*gamma2-beta2*gamma1);
    delta=A^2+B^2-C^2;
    if delta < 0, delta = 0; end
    tmp1=(A+sqrt(delta))/(B-C); tmp2=(A-sqrt(delta))/(B-C);
    theta1=atan(tmp1); theta2=atan(tmp2);
    t1=v*cos(theta1)-u*sin(theta1); t2=v*cos(theta2)-u*sin(theta2);
    T1=[ones(n,1),t1]; T2=[ones(n,1),t2];
    f1=d'*T1*pinv(T1'*T1)*T1'*d; f2=d'*T2*pinv(T2'*T2)*T2'*d;
    if f1<f2, theta=theta2; else, theta=theta1; end
    t=v*cos(theta)-u*sin(theta);
    T=[ones(n,1),t];
    a=pinv(T'*T)*T'*d;
    t_map = v_map*cos(theta) - u_map*sin(theta);
    
    % 视差结果生成
    disp1 = image_g - (a(1) + a(2) * t_map) + 30;
    disp1(image_g == 0) = 0;
    
    %% --- (5) 导出并保存四个文件  ---
    
    % 文件 1: 复制原图片到子文件夹
    copyfile(curr_full_path, fullfile(sub_folder, curr_filename));
    
    % 文件 2: 保存生成的 .mat 文件
    save(fullfile(sub_folder, [base_name, '.mat']), 'disp1', 'image_g');
    
    % 文件 3: 保存生成的 .xlsx 表格 (取整)
    disp1_int = round(disp1); 
    writematrix(disp1_int, fullfile(sub_folder, [base_name, '.xlsx']));
    
    % 文件 4: 保存结果对比图 (.jpg)
    h = figure('Visible', 'off'); 
    subplot(2,1,1); imshow(image_g, [], 'Colormap', jet(2048)); 
    title(['Original: ', base_name], 'Interpreter', 'none');
    subplot(2,1,2); imshow(disp1, [], 'Colormap', jet(2048)); 
    title('Parallax Mapping Result');
    saveas(h, fullfile(sub_folder, [base_name, '.jpg']));
    close(h);

end

fprintf('--------------------------------------------------\n');
fprintf('全部处理完成！共计 %d 个文件夹已生成在:\n%s\n', num_files, output_root);