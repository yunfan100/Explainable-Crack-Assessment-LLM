import pandas as pd
import numpy as np
from zhipuai import ZhipuAI
import os
import json
import re
import time
from scipy import ndimage
from skimage import measure

# ================= 1. 核心配置 =================
api_key = "*********************************************"
root_dir = r"D:\results"

client = ZhipuAI(api_key=api_key)

def process_expert_analysis():
    folders = [f for f in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, f))]
    total = len(folders)

    print(f"检测到 {total} 个任务。模式：超长详细推理 + 专家级双语报告")
    print("-" * 75)

    for index, base_name in enumerate(folders):
        folder_path = os.path.join(root_dir, base_name)
        input_path = os.path.join(folder_path, f"{base_name}.xlsx")

        core_file = os.path.join(folder_path, f"{base_name}_core_area.xlsx")
        edge_file = os.path.join(folder_path, f"{base_name}_edge_line.xlsx")
        txt_cn = os.path.join(folder_path, f"{base_name}_explanation_cn.txt")
        txt_en = os.path.join(folder_path, f"{base_name}_explanation_en.txt")

        # 增量逻辑
        if all(os.path.exists(f) for f in [core_file, edge_file, txt_cn, txt_en]):
            print(f"[{index + 1}/{total}] 跳过: {base_name}")
            continue

        if not os.path.exists(input_path): continue

        print(f"[{index + 1}/{total}] 正在进行超详尽逻辑推理: {base_name} ...")

        try:
            df = pd.read_excel(input_path, header=None)
            data = df.values
            stats = {
                "min": int(np.min(data)),
                "max": int(np.max(data)),
                "mean": round(float(np.mean(data)), 2),
                "std": round(float(np.std(data)), 2)
            }

            # --- 2. 【核心修改：强化提示词，要求超长字数和分层逻辑】 ---
            prompt = f"""
            Role: Senior Traffic Engineering Expert & Lead AI Vision Researcher.
            Task: Generate an ultra-detailed, multi-layered interpretability report for road crack segmentation.

            [Input Sensing Features]:
            - Min Parallax (Maximum Depth Point): {stats['min']}
            - Mean Parallax (Road Surface Average): {stats['mean']}
            - Standard Deviation (Surface Noise): {stats['std']}
            - Baseline Calibration Value: 30.0

            [Hard Constraints for Reasoning]:
            1. **Layer 1: Sensing Layer Analysis**. Detail the statistical distribution. Why is the gap between {stats['min']} and {stats['mean']} significant for structural integrity?
            2. **Layer 2: Physical Interpretation**. Describe the crack geometry. Is it a deep void, a narrow longitudinal fatigue crack, or surface raveling? Relate it to mountainous road safety.
            3. **Layer 3: Decision Logic**. Justify the selection of threshold T. Explain the trade-off between Recall (detecting thin cracks) and Precision (suppressing road texture noise).
            4. **Layer 4: Refinement Logic**. Explain why we use Connected Components to filter areas <100px and Morphological Erosion to extract the high-precision edge.

            **Language Requirements**:
            - 'thought_cn': 必须写得非常详尽，字数不少于 500 字，要求逻辑严密，语体专业。
            - 'thought_en': Academic style, at least 300 words, using professional terms (e.g., Parallax deviation, Morphological thinning).

            Return strictly in JSON format:
            {{
                "threshold": T,
                "thought_cn": "详细层层递进的中文推理...",
                "thought_en": "Step-by-step academic reasoning in English..."
            }}
            """

            response = client.chat.completions.create(
                model="glm-4-flash",
                messages=[{"role": "user", "content": prompt}]
            )

            # --- 3. 增强版解析逻辑：防止长文本中的废话干扰 ---
            full_text = response.choices[0].message.content.strip()
            try:
                # 寻找 JSON 边界，防止 AI 在前后加废话
                json_part = re.search(r'\{.*\}', full_text, re.DOTALL).group(0)
                res_json = json.loads(json_part)
                threshold = res_json['threshold']
                thought_cn = res_json['thought_cn']
                thought_en = res_json['thought_en']
            except:
                # 备选解析：如果 JSON 解析彻底失败，提取数字并记录原始回复
                num_match = re.findall(r'\d+\.?\d*', full_text)
                threshold = float(num_match[0]) if num_match else 25
                thought_cn = full_text # 如果没解析出 JSON，直接存全文
                thought_en = "See Chinese text for detailed reasoning."

            # --- 4. 裂缝提取数学逻辑 (完全保留你原来的代码内容) ---
            raw_mask = (data < threshold).astype(np.uint8)
            labels = measure.label(raw_mask)
            props = measure.regionprops(labels)

            if len(props) > 0:
                props.sort(key=lambda x: x.area, reverse=True)
                main_crack_mask = np.zeros_like(raw_mask)
                for i in range(min(2, len(props))):
                    if props[i].area > 100:
                        main_crack_mask[labels == props[i].label] = 1
            else:
                main_crack_mask = raw_mask

            core_final = np.where(main_crack_mask == 1, data, 0)
            eroded = ndimage.binary_erosion(main_crack_mask).astype(int)
            outline_mask = main_crack_mask ^ eroded
            edge_final = np.where(outline_mask == 1, data, 0)

            # --- 5. 保存结果 ---
            pd.DataFrame(core_final).to_excel(core_file, index=False, header=False)
            pd.DataFrame(edge_final).to_excel(edge_file, index=False, header=False)

            with open(txt_cn, 'w', encoding='utf-8') as f:
                f.write(f"=== 交通工程 AI 诊断报告（深度推理版） ===\n")
                f.write(f"文件名: {base_name}\n")
                f.write(f"建议阈值: {threshold}\n")
                f.write("-" * 60 + "\n")
                f.write(f"{thought_cn}\n")

            with open(txt_en, 'w', encoding='utf-8') as f:
                f.write(f"=== Interpretability Inference Report (Deep Logic) ===\n")
                f.write(f"Filename: {base_name}\n")
                f.write(f"Threshold: {threshold}\n")
                f.write("-" * 60 + "\n")
                f.write(f"{thought_en}\n")

            print(f"   -> 完成！已生成详细报告（阈值: {threshold}）")
            time.sleep(0.5)

        except Exception as e:
            print(f"   -> 异常: {base_name} 报错: {str(e)}")

    print("-" * 75)
    print("所有深度分析任务已圆满结束！")

if __name__ == "__main__":
    process_expert_analysis()